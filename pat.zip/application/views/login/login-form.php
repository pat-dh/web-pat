<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login PAT</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php  echo $title; ?></title>
    <meta name="description" content="" />
    <link rel="shortcut icon" href="" type="image/png" />
    <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/animate.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet"> 
    <link href="<?php echo base_url('assets/css/main.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet">
  	
    <style type="text/css">
    	.login {
    		
    	}
    </style>
</head>
<body>
	<header id="header">      
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                   <div class="social-icons">
                        <ul class="nav nav-pills">
                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                            <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div> 
                </div>
             </div>
        </div>
        <br>
        <div class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="navbar-brand" href="<?php echo site_url(); ?>">
                        <h1><img src="" alt="logo"></h1>
                    </a>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="<?php echo site_url(); ?>">Beranda</a></li>
                        <li><a href="">Bantuan</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="panel panel-primary login">
					<div class="panel-header">
						<legend>
                            <center>
                                <h2>Login</h2>
                                <?php echo $info;?>
                            </center>
                        </legend>
                        <?php
                          if(validation_errors() || $this->session->flashdata('result_login')) { 
                          ?>
                            <div class="alert alert-danger">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <strong>Warning!</strong>
                                <?php echo validation_errors(); ?>
                                <?php echo $this->session->flashdata('result_login'); ?>
                            </div>    
                        <?php } ?>
					</div>
					<div class="panel-body">
						<form role="form" method="post" action="<?php echo site_url('login/process');?>">
							<div class="form-group">
								<input type="text" name="username" class="form-control" placeholder="username">
							</div>
							<div class="form-group">
								<input type="password" name="password" class="form-control" placeholder="password">
							</div>
							<center>
								<div class="input-group">
									<button name="login" type="submit" class="btn btn-primary"><i class="fa fa-sign-in"></i>&nbsp;Login</button>
								</div>
							</center>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/main.js')?>"></script>
</body>
</html>