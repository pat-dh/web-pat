<!DOCTYPE html>
<html lang="en">
<head>
	<title>Pusat Al-Quran Terpadu</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php  echo $title; ?></title>
    <meta name="description" content="" />
    <link rel="shortcut icon" href="" type="image/png" />
    <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/animate.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet"> 
    <link href="<?php echo base_url('assets/css/admin.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/dataTables.bootstrap.css'); ?>" rel="stylesheet">

</head>
<body>
	<header id="header"> 
        <div class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <div class="navbar-brand">
                        <a href=""><h1><u>ADMINISTRATOR</u></h1></a>
                    </div>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="">Dashboard</a></li>
                        <li class="dropdown"><a href="#">Profil <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Visi Misi</a></li>
                                <li><a href="">Struktur Kepengurusan</a></li>
                                <li><a href="">Dosen Pengampu</a></li>
                            </ul>
                        </li>
                        <li class="dropdown"><a href="<?php echo site_url('admin/program'); ?>">Program <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Riset</a></li>
                                <li><a href="">Kajian</a></li>
                                <li><a href="">Tahsin</a></li>
                                <li><a href="">Tilawah</a></li>
                                <li><a href="">Tahfidz</a></li>
                                <li><a href="">Training</a></li>
                                <li><a href="">Kewirausahaan</a></li>
                                <li><a href="">Program Terpadu</a></li>
                                <li><a href="">Kuliah Kerja Terpadu</a></li>
                            </ul>
                        </li>                    
                        <li class="dropdown"><a href="blog.html">Materi <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Khutbah</a></li>
                                <li><a href="">Tausyiah</a></li>
                                <li><a href="">Reportase</a></li>
                                <li><a href="">Kajian</a></li>
                                <li><a href="">Kiriman Pembaca</a></li>
                            </ul>
                        </li>
                        <li class="dropdown"><a href="">Profil Alumni <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Daaru Hiraa</a></li>
                                <li><a href="">Pusat Al-Quran Terpadu</a></li>
                            </ul>
                        </li>
                        <li><a href="">Galeri Foto</a></li>
                        <li><a href="<?php echo site_url('admin/logout'); ?>">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
	<div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                <ol class="breadcrumb">
                    <li><i class="fa fa-home"></i><a href="">Home</a></li>
                    <li class="active"><i class="fa fa-laptop"></i><a>Dashboard</a></li>                          
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-1">
                <a class="quick-btn" href="#">
                    <i class="fa fa-pencil fa-2x"></i>
                    <span> Berita</span>
                    <span class="label label-danger">2</span>
                </a>
            </div>
            <div class="col-md-1">
                <a class="quick-btn" href="#">
                    <i class="fa fa-pencil fa-2x"></i>
                    <span> Berita</span>
                    <span class="label label-danger">2</span>
                </a>
            </div>
        </div>
        <br/>
		<div class="row">
			<div class="col-md-12">
				<div class="panel login">
					<div class="panel-header">
						<legend><center><h2>Dashboard</h2></center></legend>
					</div>
					<div class="panel-body">
						<div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover table-heading table-datatable" id="tabel">
                                <thead>
                                    <tr>
                                        <th>No</th>                                
                                        <th>Judul</th>
                                        <th>Penulis</th>
                                        <th>Tanggal</th>                       
                                        <th>Kategori</th>
                                        <th>Komentar</th>
                                        <th class="text-center">Pilihan</th>        
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $no=0;
                                foreach($berita as $row): $no++;
                                ?>
                                    <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $row->judul_berita; ?></td>
                                        <td></td>
                                        <td><?php echo $row->tanggal_posting; ?></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/main.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.dataTables.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/dataTables.bootstrap.js')?>"></script>
    <script>
            $(document).ready(function () {
                $('#tabel').dataTable();
            });

            $(document).ready(function () {
                $('#example1').dataTable();
            });
    </script>
</body>
</html>