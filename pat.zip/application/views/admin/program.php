	<div class="container">
        <div class="row">
            <div class="col-md-12">
                
                <ol class="breadcrumb">
                    <li><i class="fa fa-home"></i><a href="">Dashboard</a></li>
                    <li class="active"><a>Program</a></li>                          
                </ol>
            </div>
        </div>
        <br/>
		<div class="row">
			<div class="col-md-12">
				<div class="panel login">
					<div class="panel-header">
						<legend><center><h2>Data</h2></center></legend>
                        <div class="row">
                            <div class="col-md-2">
                                <a href="<?php echo site_url()?>/admin/program/tambah" class="btn btn-primary" style="margin-left:10px;"><i class="fa fa-plus"></i>&nbsp;Tambah Program</a>                                                          
                            </div>                            
                        </div>                        
					</div>
					<div class="panel-body">
						<div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover table-heading table-datatable" id="tabel">
                                <thead>
                                    <tr>
                                        <th>No</th>                                
                                        <th>Nama Program</th>
                                        <th>Deskripsi</th>
                                        <th class="text-center">Pilihan</th>        
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $no=0; foreach($program as $row): $no++;
                                ?>
                                    <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $row->nama_program; ?></td>
                                        <td><?php echo $row->deskripsi; ?></td>
                                        <td width="150" align="center">
                                            <a href="<?php echo site_url()?>/admin/program/edit/<?php echo $row->id_program ?>">
                                                <i class="fa fa-edit"></i>&nbsp;Edit
                                            </a>&nbsp; | &nbsp;
                                            <a href="<?php echo site_url()?>/admin/program/hapus/<?php echo $row->id_program ?>">
                                                <i class="fa fa-trash-o"></i>&nbsp;Hapus
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</div>