    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/main.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.dataTables.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/dataTables.bootstrap.js')?>"></script>
    <script>
            $(document).ready(function () {
                $('#tabel').dataTable();
            });

            $(document).ready(function () {
                $('#example1').dataTable();
            });
    </script>
</body>
</html>