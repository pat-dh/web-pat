<!DOCTYPE html>
<html lang="en">
<head>
	<title>Pusat Al-Quran Terpadu</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php  echo $title; ?></title>
    <meta name="description" content="" />
    <link rel="shortcut icon" href="" type="image/png" />
    <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/animate.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet"> 
    <link href="<?php echo base_url('assets/css/admin.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/dataTables.bootstrap.css'); ?>" rel="stylesheet">

</head>
<body>
	<header id="header"> 
        <div class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <div class="navbar-brand">
                        <a href=""><h1><u>ADMINISTRATOR</u></h1></a>
                    </div>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?php echo site_url('admin'); ?>">Dashboard</a></li>
                        <li class="dropdown"><a href="#">Profil <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Visi Misi</a></li>
                                <li><a href="">Struktur Kepengurusan</a></li>
                                <li><a href="">Dosen Pengampu</a></li>
                            </ul>
                        </li>
                        <li class="dropdown"><a href="<?php echo site_url('admin/program'); ?>">Program <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Riset</a></li>
                                <li><a href="">Kajian</a></li>
                                <li><a href="">Tahsin</a></li>
                                <li><a href="">Tilawah</a></li>
                                <li><a href="">Tahfidz</a></li>
                                <li><a href="">Training</a></li>
                                <li><a href="">Kewirausahaan</a></li>
                                <li><a href="">Program Terpadu</a></li>
                                <li><a href="">Kuliah Kerja Terpadu</a></li>
                            </ul>
                        </li>                    
                        <li class="dropdown"><a href="blog.html">Materi <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Khutbah</a></li>
                                <li><a href="">Tausyiah</a></li>
                                <li><a href="">Reportase</a></li>
                                <li><a href="">Kajian</a></li>
                                <li><a href="">Kiriman Pembaca</a></li>
                            </ul>
                        </li>
                        <li class="dropdown"><a href="">Profil Alumni <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="">Daaru Hiraa</a></li>
                                <li><a href="">Pusat Al-Quran Terpadu</a></li>
                            </ul>
                        </li>
                        <li><a href="">Galeri Foto</a></li>
                        <li><a href="<?php echo site_url('admin/logout'); ?>">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>