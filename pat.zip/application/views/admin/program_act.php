<?php
$act = $this->uri->segment(3);

if ($act == "tambah" || $act == "tambah_act") {
    $action     = "tambah_act";
    $id         = "";
    $nama       = "";
    $deskripsi  = "";
} else if ($act == "edit"  || $act == "edit_act") {
    $action     = "edit_act";
    $id         = $program->id_program;
    $nama       = $program->nama_program;
    $deskripsi  = $program->deskripsi;
}

?>

	<div class="container">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><i class="fa fa-home"></i><a href="">Dashboard</a></li>
                    <li><a>Program</a></li>
                    <li class="active"><a>Action</a></li>
                </ol>
            </div>
        </div>
        <br/>
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-header">
						<legend><center><h2>Tambah Program</h2></center></legend>
					</div>
					<div class="panel-body">
                        <form role="form" method="post" class="form-horizontal" action="<?php echo site_url()?>/admin/program/<?=$action?>/<?=$id?>">
                            <input type="hidden" name="id" value="<?=$id?>">
                            <div class="form-group">
                                <label class="control-label col-md-2">Nama Program</label>
                                <div class="col-md-6">
                                <input type="text" name="nama" value="<?=$nama?>" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2">Deskripsi</label>
                                <div class="col-md-6">
                                    <textarea name="desc" value="<?=$deskripsi?>" class="form-control" style="height:200px;" required><?=$deskripsi?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-2">
                                    <button type="submit">Simpan</button>
                                    <button type="reset">Reset</button>
                                </div>
                            </div>
                        </form>
					</div>
				</div>
			</div>
		</div>
	</div>
	