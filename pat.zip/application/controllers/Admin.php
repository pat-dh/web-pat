<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class Admin extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		$this->load->helper(array('form', 'url'));
		$this->load->library(array('Pagination','image_lib','form_validation'));
		$this->load->helper("file");
	}

	public function index() {
		if(! $this->session->userdata('validated')){
            redirect('login');
        }

        $admin['berita'] 	= $this->admin_model->getAll('khutbah');		
		$this->load->view('admin/index.php',$admin);
	}

	public function program() {
		if(! $this->session->userdata('validated')){
            redirect('login');
        }

        $ke	= $this->uri->segment(3);

        $this->load->view('admin/header');

        if ($ke == "tambah") {
        	$admin['program'] = $this->admin_model->getAll('program');
			$this->load->view('admin/program_act', $admin);
        }
        elseif ($ke == "tambah_act") {
        	$data['nama_program'] = $this->input->post('nama');
        	$data['deskripsi'] = $this->input->post('desc');
        	$this->admin_model->ADD('program',$data);
        	redirect('admin/program');
        }
        elseif ($ke == "edit") {
        	$id_prog = $this->uri->segment(4);
        	$admin['program'] = $this->admin_model->getAll('program');
        	$admin['program'] = $this->admin_model->getDataByID('program', 'id_program', $id_prog);
			$this->load->view('admin/program_act', $admin);
        }
        elseif ($ke == "edit_act") {
        	$id['id_program'] =  $this->input->post('id');
        	$data['nama_program'] = $this->input->post('nama');
        	$data['deskripsi'] = $this->input->post('desc');
        	$this->admin_model->EDIT('program',$data, $id);
        	redirect('admin/program');
        }
        elseif ($ke == "hapus") {
        	$id_prog = $this->uri->segment(4);
        	$this->admin_model->delData('program', 'id_program', $id_prog);
			redirect('admin/program');
        }
        else {
        	$admin['program'] = $this->admin_model->getAll('program');
        	$this->load->view('admin/program',$admin);
        }
        $this->load->view('admin/footer');
	}

	public function logout(){
        $this->session->sess_destroy();
        redirect('web');
    }
}