jQuery(function($) {'use strict';

	$('li.dropdown').find('.fa-angle-down').each(function(){
		$(this).on('click', function(){
			if( $(window).width() < 768 ) {
				$(this).parent().next().slideToggle();
			}
			return false;
		});
	});

	$('.fa-search').on('click', function() {
		$('.field-toggle').fadeToggle(200);
	});


});